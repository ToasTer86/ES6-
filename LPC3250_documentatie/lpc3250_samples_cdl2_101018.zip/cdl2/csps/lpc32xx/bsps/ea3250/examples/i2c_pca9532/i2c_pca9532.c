/***********************************************************************
 * $Id:: mi2c_example.c 2095 2009-07-28 19:12:10Z wellsk               $
 *
 * Project: NXP PHY3250 I2C example
 *
 * Description:
 *     This file contains a I2C master mode example that queries a
 *     few I2C registers of the UDA1380. A register is changed, then
 *     queries again, then reset to it's original state.
 *
 ***********************************************************************
 * Software that is described herein is for illustrative purposes only
 * which provides customers with programming information regarding the
 * products. This software is supplied "AS IS" without any warranties.
 * NXP Semiconductors assumes no responsibility or liability for the
 * use of the software, conveys no license or title under any patent,
 * copyright, or mask work right to the product. NXP Semiconductors
 * reserves the right to make changes in the software without
 * notification. NXP Semiconductors also make no representation or
 * warranty that such application will be suitable for the specified
 * use without further testing or modification.
 **********************************************************************/

#include "lpc_types.h"
#include "lpc_arm922t_cp15_driver.h"
#include "lpc_irq_fiq.h"
#include "lpc32xx_chip.h"
#include "lpc32xx_intc_driver.h"
#include "lpc32xx_gpio_driver.h"
#include "lpc32xx_mstr_i2c_driver.h"

/***********************************************************************
 * I2C example private functions and data
 **********************************************************************/

/* Prototype for external IRQ handler */
void lpc32xx_irq_handler(void);

/* I2C device handles */
static INT_32 mi2cdev;

#define PCA9532_ADDR 0x60

#define PCA9532_INPUT0 0x00
#define PCA9532_INPUT1 0x01
#define PCA9532_PSC0   0x02
#define PCA9532_PWM0   0x03
#define PCA9532_PSC1   0x04
#define PCA9532_PWM1   0x05
#define PCA9532_LS0    0x06
#define PCA9532_LS1    0x07
#define PCA9532_LS2    0x08
#define PCA9532_LS3    0x09

#define PCA9532_AUTO_INC 0x10

#define LED1 (1 << 0)
#define LED2 (1 << 2)
#define LED3 (1 << 4)
#define LED4 (1 << 6)

#define KEY1 0x01
#define KEY2 0x02
#define KEY3 0x04
#define KEY4 0x08

static void setLeds(UNS_8 leds) 
{
  UNS_32 rxdata[8], txdata[8];
  I2C_MTXRX_SETUP_T xfer;
  UNS_32 status;

  txdata[0] = (PCA9532_ADDR << 1) | I2C_START | 0;
  txdata[1] = PCA9532_LS2;
  txdata[2] = leds | I2C_STOP;
/*
  txdata[2] = (I2CADDR << 1) | I2C_START | 1;
  txdata[3] = 0xFF;
  txdata[4] = 0xFF | I2C_STOP;
*/
  xfer.tx_data = txdata;
  xfer.rx_data = rxdata;
  xfer.tx_length = 3;
  xfer.clock_rate = 100000;
  xfer.cb = NULL;

  if (i2c_mstr_ioctl(mi2cdev, I2C_MSTR_TRANSFER, (INT_32) &xfer) ==
	  _NO_ERROR) {
		  status = i2c_mstr_ioctl(mi2cdev, I2C_MSTR_GET_STATUS, 0);
		  while ((status & (I2C_MSTR_STATUS_ARBF |
			  I2C_MSTR_STATUS_NOACKF | I2C_MSTR_STATUS_DONE)) == 0) {
				  status = i2c_mstr_ioctl(mi2cdev,
					  I2C_MSTR_GET_STATUS, 0);
		  }
  }
}

static UNS_8 readKeys(void)
{
  UNS_32 rxdata[8], txdata[8];
  I2C_MTXRX_SETUP_T xfer;
  UNS_32 status;

  txdata[0] = (PCA9532_ADDR << 1) | I2C_START | 0; // write
  txdata[1] = PCA9532_INPUT0;
  txdata[2] = (PCA9532_ADDR << 1) | I2C_START | 1; // read
  txdata[3] = 0xFF | I2C_STOP;
  xfer.tx_data = txdata;
  xfer.rx_data = rxdata;
  xfer.tx_length = 4;
  xfer.clock_rate = 100000;
  xfer.cb = NULL;

  if (i2c_mstr_ioctl(mi2cdev, I2C_MSTR_TRANSFER, (INT_32) &xfer) ==
	  _NO_ERROR) {
		  status = i2c_mstr_ioctl(mi2cdev, I2C_MSTR_GET_STATUS, 0);
		  while ((status & (I2C_MSTR_STATUS_ARBF |
			  I2C_MSTR_STATUS_NOACKF | I2C_MSTR_STATUS_DONE)) == 0) {
				  status = i2c_mstr_ioctl(mi2cdev,
					  I2C_MSTR_GET_STATUS, 0);
		  }
  }
  
  return (rxdata[0]);
}



/***********************************************************************
 *
 * Function: c_entry
 *
 * Purpose: Application entry point from the startup code
 *
 * Processing:
 *     See function.
 *
 * Parameters: None
 *
 * Outputs: None
 *
 * Returns: Nothing
 *
 * Notes: None
 *
 **********************************************************************/
void c_entry(void)
{
  UNS_8 keys = 0;
  UNS_8 leds = 0;

  /* Disable interrupts in ARM core */
  disable_irq();


  /* Set virtual address of MMU table */
  cp15_set_vmmu_addr((void *)
                     (IRAM_BASE + (256 * 1024) - (16 * 1024)));

  /* Initialize interrupt system */
  int_initialize(0xFFFFFFFF);

  /* Install standard IRQ dispatcher at ARM IRQ vector */
  int_install_arm_vec_handler(IRQ_VEC, (PFV) lpc32xx_irq_handler);

  /* Install I2C interrupt handlers */
  int_install_irq_handler(IRQ_I2C_1, (PFV) i2c1_mstr_int_hanlder);

  /* Enable IRQ interrupts in the ARM core */
  enable_irq();
  int_enable(IRQ_I2C_1);

  /* Open I2C device */
  mi2cdev = i2c_mstr_open((void *) I2C1, 0);
  if (mi2cdev == 0)
	  return;

  while (1) {
    leds = 0;
    keys = readKeys();

    if ((keys & KEY1) == 0) {
      leds |= LED1;
    }
    if ((keys & KEY2) == 0) {
      leds |= LED2;
    }
    if ((keys & KEY3) == 0) {
      leds |= LED3;
    }
    if ((keys & KEY4) == 0) {
      leds |= LED4;
    }

    setLeds(leds);

  }
  

exit1:
  /* close I2C device */    
  i2c_mstr_close(mi2cdev);
}
