Description
-----------

This example is setting up a timer and will toggle a 
LED on the OEM Board




