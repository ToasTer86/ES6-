Description
-----------

This example is demonstrating the use of the RTC 
(real time clock). 




