Description
-----------

This example demonstrates the use of the SLC NAND interface
and will read and write to the NAND flash.



Build files
-----------
This example has only been verified to work when built with
Keil's uVision and therefore no makefile exist in the project
file.
