Description
-----------

This example is setting up a MS timer and will toggle a 
LED on the OEM Board




