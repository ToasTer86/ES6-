/***********************************************************************
 * $Id$
 *
 * Project: RTC driver example
 *
 * Description:
 *     A simple RTC driver example with interrupts.
 *
 ***********************************************************************
 * Software that is described herein is for illustrative purposes only
 * which provides customers with programming information regarding the
 * products. This software is supplied "AS IS" without any warranties.
 * NXP Semiconductors assumes no responsibility or liability for the
 * use of the software, conveys no license or title under any patent,
 * copyright, or mask work right to the product. NXP Semiconductors
 * reserves the right to make changes in the software without
 * notification. NXP Semiconductors also make no representation or
 * warranty that such application will be suitable for the specified
 * use without further testing or modification.
 **********************************************************************/

#include <stdio.h>
#include <string.h>

#include "lpc_types.h"
#include "lpc_irq_fiq.h"
#include "lpc_swim.h"
#include "lpc_swim_font.h"
#include "lpc_lcd_params.h"
#include "lpc_arm922t_cp15_driver.h"
#include "lpc32xx_rtc_driver.h"
#include "lpc32xx_intc_driver.h"
#include "lpc32xx_gpio_driver.h"
#include "lpc32xx_clcdc_driver.h"
#include "lpc32xx_clkpwr_driver.h"
#include "lpc32xx_uart_driver.h"
#include "lpc32xx_dma_driver.h"

#include "board_slc_nand_lb_driver.h"
#include "common_funcs.h"

#include "uart.h"

/* Prototype for external IRQ handler */
void lpc32xx_irq_handler(void);

static UNS_8 page_buf[LARGE_BLOCK_PAGE_MAIN_AREA_SIZE];
static UNS_8 spare_buf[LARGE_BLOCK_PAGE_SPARE_AREA_SIZE];

/* UART buffer */
static char buff[512];

#define TEST_BLOCK 100
#define TEST_PAGE  0

/* enable this define to write to the NAND flash */
#define USEWRITE

/***********************************************************************
 *
 * Function: dump_data
 *
 * Purpose: Dump some values to the console
 *
 * Processing:
 *     Converts the values in the passed array to strings and displays
 *     them in the console.
 *
 * Parameters: None
 *
 * Outputs: None
 *
 * Returns: Nothing
 *
 * Notes: None
 *
 **********************************************************************/
void dump_data(char *str,
			   void *data,
			   int bytes)
{
  int i = 0;

  sprintf(buff, "%s\r\n%3x: ", str, 0);
  uart_output((UNS_8*)buff);

  for (i = 0; i < bytes; i++) {
    if (i > 0 && (i%16) == 0) {
      sprintf(buff, "\r\n%3x: ", i);
      uart_output((UNS_8*)buff);    
    }

    sprintf(buff, "%02x ", ((char*)data)[i]);
    uart_output((UNS_8*)buff);    


    
  }
  uart_output("\r\n"); 
}

/***********************************************************************
 *
 * Function: c_entry
 *
 * Purpose: Application entry point from the startup code
 *
 * Processing:
 *     See function.
 *
 * Parameters: None
 *
 * Outputs: None
 *
 * Returns: Always returns 1, or <0 on an error
 *
 * Notes: None
 *
 **********************************************************************/
int c_entry(void)
{
  int idx = 0;
  UNS_32 sector = 0;

  /* Disable interrupts in ARM core */
  disable_irq_fiq();

  /* Set virtual address of MMU table */
  cp15_set_vmmu_addr((void *)
                     (IRAM_BASE + (256 * 1024) - (16 * 1024)));

  /* Initialize interrupt system */
  int_initialize(0xFFFFFFFF);

  /* Install standard IRQ dispatcher at ARM IRQ vector */
  int_install_arm_vec_handler(IRQ_VEC, (PFV) lpc32xx_irq_handler);

  /* Setup DMA */
  dma_init();

  uart_output_init();


  /* Enable IRQ interrupts in the ARM core */
  enable_irq();

  nand_flash_wp_disable();

  if (!nand_lb_slc_init()) {
    uart_output("Failed to initialize SLC\r\n");
    goto testfail;
  }

  sector = nand_bp_to_sector(TEST_BLOCK, TEST_PAGE);

#ifdef USEWRITE

  if (!nand_lb_slc_erase_block(TEST_BLOCK)) {
    uart_output("Failed to erase block\r\n");
    goto testfail;
  }

  /* Generate a test pattern for the page */
  for (idx = 0; idx < LARGE_BLOCK_PAGE_MAIN_AREA_SIZE; idx++)
  {
	  page_buf [idx] = (UNS_8)(idx+0);
  }

  if (nand_lb_slc_write_sector(sector, page_buf, NULL) < 0) {
    uart_output("Failed to write sector\r\n");
    goto testfail;
  }


#endif

  if (nand_lb_slc_read_sector(sector, page_buf, spare_buf) < 0) {
    uart_output("Failed to read sector\r\n");
    goto testfail;    
  }

  /* Dump first 32 bytes of data from page */
  dump_data("First 32 bytes read from NAND", page_buf, 32);

#ifdef USEWRITE
  /* Verify test pattern for the page */
  for (idx = 0; idx < LARGE_BLOCK_PAGE_MAIN_AREA_SIZE; idx++)
  {
	  if (page_buf [idx] != (UNS_8)(idx+0))
	  {
      uart_output("Read data invalid (validation failed)\r\n");
	    goto testfail;
	  }
  }
#endif

testfail:
  /* Disable interrupts in ARM core */
  disable_irq_fiq();



  return 1;
}
