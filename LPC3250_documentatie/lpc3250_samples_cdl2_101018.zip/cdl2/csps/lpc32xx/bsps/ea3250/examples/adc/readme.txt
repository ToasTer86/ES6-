Description
-----------

This example demonstrates the use of ADC. The trimpot
and accelerometer is monitored and values written to the
UART.