Description
-----------

This example demonstrates the use of the Ethernet interface
and will respond to ICMP (ping) requests. By default the
IP address is set to 192.168.5.241, but can be changed in
eth_example.c


Build files
-----------
This example has only been verified to work when built with
Keil's uVision and therefore no makefile exist in the project
file.
