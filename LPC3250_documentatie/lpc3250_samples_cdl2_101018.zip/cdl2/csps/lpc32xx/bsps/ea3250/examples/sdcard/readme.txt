Description
-----------

This example demonstrates the use of the SDCard driver. It 
will try to open a file named testfile.txt and read
100 bytes.


Build files
-----------
This example has only been verified to work when built with
Keil's uVision and therefore no makefile exist in the project
file.
