
#include <stdio.h>
#include <string.h>

#include "lpc_types.h"
#include "lpc_irq_fiq.h"
#include "lpc_swim.h"
#include "lpc_swim_font.h"
#include "lpc_lcd_params.h"
#include "lpc_arm922t_cp15_driver.h"
#include "lpc32xx_rtc_driver.h"
#include "lpc32xx_intc_driver.h"
#include "lpc32xx_gpio_driver.h"
#include "lpc32xx_clcdc_driver.h"
#include "lpc32xx_clkpwr_driver.h"
#include "lpc32xx_uart_driver.h"
#include "board_spi_flash_driver.h"

#include "uart.h"

/* Prototype for external IRQ handler */
void lpc32xx_irq_handler(void);


#define BUF_SZ 512
#define NOR_OFFSET 0
 //(4*1024*1024-(64*1024)) 

#define DO_WRITE

/* UART buffer */
static char buff[512];

/***********************************************************************
 *
 * Function: c_entry
 *
 * Purpose: Application entry point from the startup code
 *
 * Processing:
 *     See function.
 *
 * Parameters: None
 *
 * Outputs: None
 *
 * Returns: Always returns 1, or <0 on an error
 *
 * Notes: None
 *
 **********************************************************************/
int c_entry(void)
{
  UNS_8 data[BUF_SZ];
  UNS_8 wrbuf[BUF_SZ];
  INT_32 status = 0;
  UNS_32 pageSize = 0;

  int i = 0;  

  /* Disable interrupts in ARM core */
  disable_irq_fiq();

  /* Set virtual address of MMU table */
  cp15_set_vmmu_addr((void *)
                     (IRAM_BASE + (256 * 1024) - (16 * 1024)));

  /* Initialize interrupt system */
  int_initialize(0xFFFFFFFF);

  /* Install standard IRQ dispatcher at ARM IRQ vector */
  int_install_arm_vec_handler(IRQ_VEC, (PFV) lpc32xx_irq_handler);


  uart_output_init();

  /* Enable IRQ interrupts in the ARM core */
  enable_irq();


  if (board_spi_config() == _ERROR) {
    /* Failed to initialize SPI NOR */
    uart_output("Failed to initialize SPI NOR\r\n");  
    return -1;     
  }


  pageSize = board_spi_getPageSize();

  sprintf(buff, "NOR flash page size=%d\r\n", pageSize);
  uart_output((UNS_8*)buff);  

#ifdef DO_WRITE
  memset (wrbuf, 0, BUF_SZ);

  for ( i = 0; i < pageSize; i++)
    wrbuf[i] = (UNS_8)(i+0);
  
  board_spi_block_erase(NOR_OFFSET);
  status = board_spi_write_page(wrbuf, NOR_OFFSET);
  if (status < 0)
    uart_output("Failed to write to flash\r\n");  
    
#endif


  status = board_spi_read(data, NOR_OFFSET, pageSize);
  if (status < 0)
    uart_output("Failed to read from flash\r\n");  

  for (i = 0; i < pageSize; i++)
  {
    if (i > 0 && (i % 8) == 0)
      uart_output("\r\n");

    sprintf(buff, "%2x%c", data[i], (((i+1)%8)==0) ? ' ' : ':');
    uart_output((UNS_8*)buff);      
  }
  uart_output("\r\n");

#ifdef DO_WRITE

  for ( i = 0; i < pageSize; i++)
  {
    if (data[i] != (UNS_8)(i+0))
    {
      sprintf(buff, "Verification failed of read data %x != %x\r\n", 
        i, data[i]);
      uart_output((UNS_8*)buff);
      break;
    }    
  }

#endif


  /* Disable interrupts in ARM core */
  disable_irq_fiq();


  return 1;
}
