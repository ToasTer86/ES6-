Description
-----------

This example is setting up a HS timer and will toggle LED1 




