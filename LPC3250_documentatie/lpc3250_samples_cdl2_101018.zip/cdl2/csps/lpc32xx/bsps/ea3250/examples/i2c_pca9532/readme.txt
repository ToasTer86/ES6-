Description
-----------

This example communicating with the PCA9532 device
on the base board (via I2C). It will monitor the state
of the buttons and turn on/off the LED above the button 




