Description
-----------

This example is using ChaN's Fat FS Module to demonstrate 
the use of the MMC/SD card on the QVGA base board. It will
list the content of the root directory.

http://elm-chan.org/fsw/ff/00index_e.html


