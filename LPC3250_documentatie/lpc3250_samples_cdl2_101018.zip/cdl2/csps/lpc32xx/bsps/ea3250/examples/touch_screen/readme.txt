Description
-----------

This example demonstrates the use the 3.2 inch QVGA display
on the QVGA base board and also the touch interface on that
display.

NOTE: The it is not a good example of how to write a touch
      screen driver. The calibration routine should e.g.
      read several values from each touch point.
      Since the example isn't doing this the result will
      be bad, i.e., you will see a lot of noice and 
      offset problems when touching the display.



Build files
-----------
This example has only been verified to work when built with
Keil's uVision and therefore no makefile exist in the project
file.
