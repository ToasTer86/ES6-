Description
-----------

This example is reading and writing to the UART.




