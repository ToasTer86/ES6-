Description
-----------

This example Is demonstrating the use of the 3.2 inch
QVGA display on the QVGA Base Board.




