Description
-----------

This example demonstrates the use of SPI NOR flash and will
read and write to the NOR flash.



Build files
-----------
This example has only been verified to work when built with
Keil's uVision and therefore no makefile exist in the project
file.
